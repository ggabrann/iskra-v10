#!/usr/bin/env bash
set -euo pipefail
export PORT="${PORT:-8080}"
export APP_MODULE="${APP_MODULE:-server:app}"

# 1) автоподстановка зависимостей
if [ -f requirements.txt ]; then
  python -m pip install -r requirements.txt >/dev/null || true
fi

# 2) подстраховка для uvicorn
if ! command -v uvicorn >/dev/null 2>&1; then
  python -m pip install uvicorn >/dev/null
fi

echo "Starting dev server on 0.0.0.0:${PORT} (module: ${APP_MODULE})"
which python; which pip; python -V
exec uvicorn "${APP_MODULE}" --host 0.0.0.0 --port "${PORT}" --reload
