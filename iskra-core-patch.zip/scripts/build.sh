#!/usr/bin/env bash
set -euo pipefail
IMAGE_TAG="${IMAGE_TAG:-iskra-core:local}"
docker build -t "${IMAGE_TAG}" .
echo "Built ${IMAGE_TAG}"
