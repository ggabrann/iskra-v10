#!/usr/bin/env bash
set -euo pipefail

if ! command -v flyctl >/dev/null 2>&1; then
  echo "Installing flyctl..."
  curl -L https://fly.io/install.sh | sh
  export FLYCTL_INSTALL="$HOME/.fly"
  export PATH="$FLYCTL_INSTALL/bin:$PATH"
fi

APP_NAME="${FLY_APP_NAME:-}"
if [ -z "$APP_NAME" ]; then
  APP_NAME="$(awk -F '\"' '/^app\s*=/{print $2}' fly.toml || true)"
fi
if [ -z "$APP_NAME" ] || [[ "$APP_NAME" == *"CHANGE-ME"* ]]; then
  echo "ERROR: Set FLY_APP_NAME secret or update app name in fly.toml"; exit 1
fi

if [ -n "${FLY_API_TOKEN:-}" ]; then
  flyctl auth token "$FLY_API_TOKEN" >/dev/null
fi

if ! flyctl apps list | grep -q "^${APP_NAME}\b"; then
  echo "Creating Fly app ${APP_NAME}..."
  flyctl apps create "${APP_NAME}"
fi

echo "Deploying ${APP_NAME}..."
flyctl deploy --remote-only --app "${APP_NAME}" --build-arg APP_MODULE="${APP_MODULE:-server:app}"
echo "Deployment finished."
flyctl status --app "${APP_NAME}" || true
