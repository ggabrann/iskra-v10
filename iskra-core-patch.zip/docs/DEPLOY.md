# Iskra Core — Fly.io deploy quickstart

1) В `fly.toml` замени `iskra-core-CHANGE-ME` на уникальное имя **или** задай секрет `FLY_APP_NAME` в GitHub.
2) В GitHub → Settings → Secrets and variables → Actions добавь:
   - `FLY_API_TOKEN`
   - `FLY_APP_NAME`
3) Локально (или в Codespaces) деплой вручную:
   ```bash
   bash scripts/deploy.sh
   ```
4) Автодеплой сработает при пуше в `main`.
5) Локальный дев:
   ```bash
   make dev
   # http://localhost:8080
   ```
