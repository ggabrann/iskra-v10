# iskra_core — дирижёр
