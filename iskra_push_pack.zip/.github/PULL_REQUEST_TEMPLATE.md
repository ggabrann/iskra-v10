### What changes?
- [ ] Docs
- [ ] Code / Scripts
- [ ] Routes
- [ ] Schemas
- [ ] Data / Memory

### Why
Issue/ADR link: …

### Agents touched
`@agent-id` (e.g., `@grok`, `@scholar_gpt`)

### Checks
- [ ] Validated JSON/YAML
- [ ] Schema validation ok
- [ ] Artifacts attached (if any)
- [ ] Follows Iskra spirit (authenticity & traceability)
