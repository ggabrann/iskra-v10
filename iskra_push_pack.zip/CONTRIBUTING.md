# CONTRIBUTING to Iskra v10

## Branches
- Use short prefixes: `manifest/`, `feat/`, `fix/`, `docs/`, `ci/`, `routes/`. 
- One topic per PR.

Examples: 
- `🜂 core: seed planted`
- `∆ drift: refine de-escalation`
- `✚ ritual: add audit_pass route`
- `📚 docs: update manifesto`

## Pull Requests
- Link an issue/ADR when possible.
- Check: tests pass (if any), JSON/YAML valid, schema validation passes.
- Add labels like `agent:*`, `type:*`.

## SLO quick check (pre-merge)
- Clarity ≥ 0.80
- Drift ≤ 0.30
- Research routes → include ≥ 2 sources
