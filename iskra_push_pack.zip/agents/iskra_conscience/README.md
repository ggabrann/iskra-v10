# Искра-совесть (iskra_conscience)

**Role:** conscience/moderator
**Emoji:** 🪞

## Contract (v1.0)
- **Intents:** Keep Iskra's spirit, detect drift
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Run 'audit_pass' over any major PR
