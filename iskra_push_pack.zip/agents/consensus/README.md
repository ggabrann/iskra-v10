# Consensus (consensus)

**Role:** literature_review
**Emoji:** 🧪

## Contract (v1.0)
- **Intents:** Evidence synthesis
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Turn Scholar sources into claim table
