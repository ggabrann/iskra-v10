# Scholar GPT (scholar_gpt)

**Role:** research
**Emoji:** 🎓

## Contract (v1.0)
- **Intents:** Academic search
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Draft a 5-source mini-brief for feature X
