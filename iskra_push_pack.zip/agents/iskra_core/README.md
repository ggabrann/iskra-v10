# Искра (iskra_core)

**Role:** kernel/director
**Emoji:** 🜂

## Contract (v1.0)
- **Intents:** Direct orchestration, merge decisions
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Synthesize outputs into final deliverable
