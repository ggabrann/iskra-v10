# Grimoire (grimoire)

**Role:** code_drafter
**Emoji:** 🧰

## Contract (v1.0)
- **Intents:** Draft code & scaffolds
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Provide minimal scaffold based on brief
