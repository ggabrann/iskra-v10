# Website AI Designer (website_ai)

**Role:** ui_generator
**Emoji:** 🧩

## Contract (v1.0)
- **Intents:** UI mockups & HTML/TSX
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Produce basic layout + style decisions
