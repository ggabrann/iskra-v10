# R Wizard (r_wizard)

**Role:** analysis/visualization
**Emoji:** 📈

## Contract (v1.0)
- **Intents:** Plots, stats
- **Inputs:** see `schema/agent_contract.schema.json`
- **Outputs:** artifacts in `runs/<run_id>/artifacts/`

## Hand-off
Receives payload from previous step, appends its `report.md` and structured `index.json`.

## First task
Build 1 chart + notes from available data
